"""Tkinter desktop interface for Tic-Tac-Toe AI."""
import tkinter as tk
from tkinter import messagebox
from engine import AI, HUMAN, new_board, outcome, apply_move, best_ai_move

BG = "#101827"
PANEL = "#19263a"
ACCENT = "#37c9b2"
X_COLOR = "#69b8ff"
O_COLOR = "#ffbb79"

class TicTacToeApp:
    def __init__(self, window):
        self.window = window
        self.window.title("Tic-Tac-Toe | Minimax AI")
        self.window.geometry("440x590")
        self.window.minsize(380, 510)
        self.window.configure(bg=BG)
        self.board = new_board()
        self.ai_pending = False
        self.generation = 0
        self.scores = {"Human": 0, "AI": 0, "Draw": 0}
        self.status = tk.StringVar(value="Your turn: X")
        self.score_label = tk.StringVar()
        tk.Label(window, text="TIC-TAC-TOE", bg=BG, fg="white",
                 font=("Arial", 26, "bold")).pack(pady=(28, 4))
        tk.Label(window, text="You are X   •   Minimax AI is O", bg=BG,
                 fg="#a6b6cb", font=("Arial", 12)).pack(pady=(0, 20))
        frame = tk.Frame(window, bg=BG)
        frame.pack(expand=True)
        self.buttons = []
        for i in range(9):
            button = tk.Button(
                frame, text="", width=4, height=2, bg=PANEL, fg="white",
                activebackground="#2b3f59", relief="flat",
                font=("Arial", 29, "bold"), cursor="hand2",
                command=lambda index=i: self.human_move(index))
            button.grid(row=i // 3, column=i % 3, padx=5, pady=5, sticky="nsew")
            self.buttons.append(button)
        for i in range(3):
            frame.grid_columnconfigure(i, weight=1)
            frame.grid_rowconfigure(i, weight=1)
        tk.Label(window, textvariable=self.status, bg=BG, fg=ACCENT,
                 font=("Arial", 15, "bold")).pack(pady=(18, 8))
        tk.Label(window, textvariable=self.score_label, bg=BG, fg="#c6d3e3",
                 font=("Arial", 11)).pack(pady=5)
        tk.Button(window, text="New Game", bg=ACCENT, fg=BG, relief="flat",
                  font=("Arial", 13, "bold"), padx=28, pady=10,
                  command=self.reset).pack(pady=(15, 30))
        self.update_display()

    def update_display(self):
        for i, button in enumerate(self.buttons):
            value = self.board[i]
            button.configure(text=value, fg=X_COLOR if value == HUMAN else O_COLOR,
                             state="normal" if not value and not outcome(self.board) and not self.ai_pending else "disabled",
                             disabledforeground=X_COLOR if value == HUMAN else O_COLOR)
        self.score_label.set(
            f"Human: {self.scores['Human']}     AI: {self.scores['AI']}     Draws: {self.scores['Draw']}"
        )

    def finish_if_needed(self):
        result = outcome(self.board)
        if result is None:
            return False
        if result == HUMAN:
            self.scores["Human"] += 1
            self.status.set("You win!")
        elif result == AI:
            self.scores["AI"] += 1
            self.status.set("AI wins!")
        else:
            self.scores["Draw"] += 1
            self.status.set("It's a draw!")
        self.update_display()
        return True

    def human_move(self, position):
        if self.ai_pending or self.board[position] or outcome(self.board):
            return
        self.board = apply_move(self.board, position, HUMAN)
        self.update_display()
        if self.finish_if_needed():
            return
        self.ai_pending = True
        self.status.set("AI is thinking...")
        self.update_display()
        token = self.generation
        self.window.after(180, lambda: self.ai_move(token))

    def ai_move(self, token):
        if token != self.generation:
            return
        if outcome(self.board):
            self.ai_pending = False
            return
        self.ai_pending = False
        position = best_ai_move(self.board)
        if position is not None:
            self.board = apply_move(self.board, position, AI)
        if not self.finish_if_needed():
            self.status.set("Your turn: X")
            self.update_display()

    def reset(self):
        self.generation += 1
        self.board = new_board()
        self.ai_pending = False
        self.status.set("Your turn: X")
        self.update_display()

if __name__ == "__main__":
    app_window = tk.Tk()
    TicTacToeApp(app_window)
    app_window.mainloop()
