"""Generate reproducible output logs for the six CEP scenarios."""
from engine import *
from pathlib import Path

lines = []
def record(title, board, observation):
    lines.append(title + "\n" + board_text(board) + "\n" + observation + "\n")

b = new_board()
record("1. EMPTY BOARD", b, f"PASS: {len(legal_moves(b))} empty cells")
b = apply_move(b, 0, HUMAN)
try:
    apply_move(b, 0, AI)
    result = "FAIL: occupied move accepted"
except ValueError as ex:
    result = f"PASS: rejected ({ex})"
record("2. OCCUPIED CELL", b, result)
b = ["X","X","X","O","O","","","",""]
record("3. THREE IN A ROW", b, f"PASS: winner = {outcome(b)}; further moves = {legal_moves(b)}")
b = ["X","O","X","X","O","O","O","X","X"]
record("4. DRAW", b, f"PASS: outcome = {outcome(b)}")
b = ["O","O","","X","X","","","",""]
move = best_ai_move(b)
record("5. AI IMMEDIATE WIN", b, f"{'PASS' if move == 2 else 'FAIL'}: AI selects cell {move+1 if move is not None else 'none'}")
b = ["X","X","","O","","","","",""]
move = best_ai_move(b)
record("6. AI BLOCKS THREAT", b, f"{'PASS' if move == 2 else 'FAIL'}: AI selects cell {move+1 if move is not None else 'none'}")
output = "\n".join(lines)
Path(__file__).with_name("test_evidence.txt").write_text(output, encoding="utf-8")
print(output)
