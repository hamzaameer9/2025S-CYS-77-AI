"""Pure Tic-Tac-Toe rules and unbeatable Minimax AI (no external packages)."""
from dataclasses import dataclass
from typing import Optional

EMPTY = ""
HUMAN = "X"
AI = "O"
WIN_LINES = (
    (0, 1, 2), (3, 4, 5), (6, 7, 8),
    (0, 3, 6), (1, 4, 7), (2, 5, 8),
    (0, 4, 8), (2, 4, 6),
)

def new_board():
    return [EMPTY] * 9

def winner(board):
    for a, b, c in WIN_LINES:
        if board[a] != EMPTY and board[a] == board[b] == board[c]:
            return board[a]
    return None

def outcome(board):
    """Return 'X', 'O', 'Draw', or None while the game is ongoing."""
    result = winner(board)
    if result is not None:
        return result
    return "Draw" if all(board) else None

def legal_moves(board):
    if outcome(board) is not None:
        return []
    return [i for i, value in enumerate(board) if value == EMPTY]

def apply_move(board, position, mark):
    """Return a new board. Reject illegal or post-game moves."""
    if mark not in (HUMAN, AI):
        raise ValueError("Mark must be X or O")
    if not isinstance(position, int) or not 0 <= position < 9:
        raise ValueError("Position must be an integer from 0 to 8")
    if outcome(board) is not None:
        raise ValueError("The game is already over")
    if board[position] != EMPTY:
        raise ValueError("That cell is already occupied")
    updated = board.copy()
    updated[position] = mark
    return updated

def minimax(board, ai_turn, depth=0, alpha=float("-inf"), beta=float("inf")):
    """Score terminal states, exploring best/worst replies with alpha-beta pruning."""
    result = outcome(board)
    if result == AI:
        return 10 - depth
    if result == HUMAN:
        return depth - 10
    if result == "Draw":
        return 0
    if ai_turn:
        best = float("-inf")
        for position in legal_moves(board):
            candidate = board.copy()
            candidate[position] = AI
            best = max(best, minimax(candidate, False, depth + 1, alpha, beta))
            alpha = max(alpha, best)
            if beta <= alpha:
                break
        return best
    best = float("inf")
    for position in legal_moves(board):
        candidate = board.copy()
        candidate[position] = HUMAN
        best = min(best, minimax(candidate, True, depth + 1, alpha, beta))
        beta = min(beta, best)
        if beta <= alpha:
            break
    return best

def best_ai_move(board) -> Optional[int]:
    """Choose a legal AI move; None means the game is finished."""
    options = legal_moves(board)
    if not options:
        return None
    # Center/corners first as a consistent tie-break, without changing minimax quality.
    preferred = [4, 0, 2, 6, 8, 1, 3, 5, 7]
    best_score = float("-inf")
    best_position = None
    for position in preferred:
        if position not in options:
            continue
        candidate = board.copy()
        candidate[position] = AI
        score = minimax(candidate, False, depth=1)
        if score > best_score:
            best_score = score
            best_position = position
    return best_position

def board_text(board):
    cells = [v if v else str(i + 1) for i, v in enumerate(board)]
    return "\n---+---+---\n".join(
        " " + " | ".join(cells[r:r+3]) + " " for r in (0, 3, 6)
    )
