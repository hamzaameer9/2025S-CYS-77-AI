"""Required CEP cases plus Minimax validation. Run: python -m unittest -v"""
import unittest
from engine import *

class TestTicTacToe(unittest.TestCase):
    def test_empty_board(self):
        self.assertEqual(new_board(), [""] * 9)
        self.assertEqual(len(legal_moves(new_board())), 9)

    def test_occupied_cell_rejected(self):
        board = apply_move(new_board(), 0, HUMAN)
        with self.assertRaisesRegex(ValueError, "occupied"):
            apply_move(board, 0, AI)

    def test_horizontal_win(self):
        board = ["X", "X", "X", "O", "O", "", "", "", ""]
        self.assertEqual(outcome(board), HUMAN)
        self.assertEqual(legal_moves(board), [])

    def test_vertical_and_diagonal_wins(self):
        self.assertEqual(outcome(["O", "X", "", "O", "X", "", "O", "", ""]), AI)
        self.assertEqual(outcome(["X", "O", "", "O", "X", "", "", "", "X"]), HUMAN)

    def test_draw(self):
        board = ["X", "O", "X", "X", "O", "O", "O", "X", "X"]
        self.assertEqual(outcome(board), "Draw")
        self.assertIsNone(best_ai_move(board))

    def test_ai_takes_immediate_win(self):
        board = ["O", "O", "", "X", "X", "", "", "", ""]
        self.assertEqual(best_ai_move(board), 2)

    def test_ai_blocks_immediate_threat(self):
        board = ["X", "X", "", "O", "", "", "", "", ""]
        self.assertEqual(best_ai_move(board), 2)

    def test_no_moves_after_win(self):
        board = ["X", "X", "X", "O", "O", "", "", "", ""]
        with self.assertRaisesRegex(ValueError, "already over"):
            apply_move(board, 5, AI)

    def test_ai_never_loses_from_empty_board(self):
        # Exhaustively explore every possible human response.
        def explore(board, human_turn):
            result = outcome(board)
            self.assertNotEqual(result, HUMAN)
            if result is not None:
                return
            if human_turn:
                for pos in legal_moves(board):
                    explore(apply_move(board, pos, HUMAN), False)
            else:
                pos = best_ai_move(board)
                explore(apply_move(board, pos, AI), True)
        explore(new_board(), True)

if __name__ == "__main__":
    unittest.main()
